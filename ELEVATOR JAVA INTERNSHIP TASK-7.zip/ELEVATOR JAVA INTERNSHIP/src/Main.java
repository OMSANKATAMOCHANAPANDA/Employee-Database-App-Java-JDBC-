import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmployeeDAO dao = new EmployeeDAO();
        while (true) {
            System.out.println("\n--- Employee Management ---");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline
            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter department: ");
                    String dept = scanner.nextLine();
                    dao.addEmployee(new Employee(name, dept));
                    break;
                case 2:
                    dao.viewEmployees();
                    break;
                case 3:
                    System.out.print("Enter employee ID to update: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new department: ");
                    String newDept = scanner.nextLine();
                    dao.updateEmployee(id, newName, newDept);
                    break;
                case 4:
                    System.out.print("Enter employee ID to delete: ");
                    int delId = scanner.nextInt();
                    dao.deleteEmployee(delId);
                    break;
                case 5:
                    System.exit(0);
            }
        }
    }
}


/*
Output:-
===========
Microsoft Windows [Version 10.0.26100.4484]
(c) Microsoft Corporation. All rights reserved.

D:\ELEVATOR JAVA INTERNSHIP>javac -d bin src/*.java

D:\ELEVATOR JAVA INTERNSHIP>java -cp bin Main

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 1
Enter name: John Doe
Enter department: HR
Employee added.

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 1
Enter name: Alice
Enter department: Engineering
Employee added.

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 2
ID: 1, Name: John Doe, Dept: HR
ID: 2, Name: Alice, Dept: Engineering

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 3
Enter employee ID to update: 2
Enter new name: Alice Smith
Enter new department: Software
Employee updated.

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 2
ID: 1, Name: John Doe, Dept: HR
ID: 2, Name: Alice Smith, Dept: Software

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 4
Enter employee ID to delete: 1
Employee deleted.

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 2
ID: 2, Name: Alice Smith, Dept: Software

--- Employee Management ---
1. Add Employee
2. View Employees
3. Update Employee
4. Delete Employee
5. Exit
Enter choice: 5
*/